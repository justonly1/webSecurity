﻿<?php
echo '<script language="javascript">location.href="../index.php"</script>';
?>