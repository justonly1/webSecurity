﻿<!DOCTYPE html>
<html>

<head>

  <meta charset="UTF-8">

  <title>web安全测试系统</title>

  <link rel="stylesheet" href="http://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.1.0/css/font-awesome.min.css">

  <link rel='stylesheet' href='./css/jquery-ui.css'>
<link rel='stylesheet prefetch' href='./css/bootstrap.min.css'>

    <link rel="stylesheet" href="./css/style.css" media="screen" type="text/css" />

    <script src="./js/modernizr.js"></script>

</head>

<body>

  <body class="login-page">
<div class="login-form">

		<div class="login-content">

			<div class="form-login-error">
				<h3>Invalid login</h3>
				<p>Enter <strong>demo</strong>/<strong>demo</strong> as login and password.</p>
			</div>
			<div class="container">

			</div> <!-- /container -->
			<h1 style="text-align:center"><font color="white">web安全测试系统</h1>

			<form method="post" role="form" id="form_login" action="./index.php">

				<div class="form-group">

					<div class="input-group">
						<div class="input-group-addon">
							
						</div>

						<input type="text" class="form-control" name="username" id="username" placeholder="Username" autocomplete="off" />
					</div>

				</div>

				<div class="form-group">

					<div class="input-group">
						<div class="input-group-addon">
							
						</div>

						<input type="password" class="form-control" name="password" id="password" placeholder="Password" autocomplete="off" />
					</div>

				</div>

				<div class="form-group">
					<button name="submit" class="btn btn-primary btn-block btn-login">
						Login
					</button>
				</div>
		
			</form>

			<div style="text-align:center;clear:both;">
<script src="./gg_bd_ad_720x90.js" type="text/javascript"></script>
<script src="./follow.js" type="text/javascript"></script>
</div>

		</div>

	</div>
 </div>

  <script src='./js/jquery_and_jqueryui.js'></script>

</body>

</html>

<?php

include('config.php');
if(isset($_POST['submit']))
{
	$username = $_POST['username'];
	$password = $_POST['password'];

	//  取得查询结果
	$check_query = mysql_query("select * from user where username='$username' and password='$password'");

	if ($result = mysql_fetch_array($check_query)) 
	{
		//  当验证通过后，启动 Session
		@session_start();
		//  注册登陆成功的 admin 变量，并赋值 true
		$_SESSION["admin"] = true;
		echo '<script language="javascript">location.href="admin/index.php"</script>';
	} 
	else 
	{
		die("用户名或密码错误");
	}   
}
?>
